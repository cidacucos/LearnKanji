* うまく利用できない場合、Maromin_Mincho_Nomodification.otf, Maromin_Regular_Nomodification.otfをご利用いただくと使える可能性があります。こちらのバージョンでは縦書きに対応しておりません。

* 一部Adobe製品で、「まろみん ふつう」と「まろみん みんちょう」が共存できない問題があります。この場合、MarominMincho-Regular.otfをインストールすると「まろみんみんちょう」というフォントが追加されるので、「みんちょう」としてそちらをご利用ください。